﻿// Saper.cpp : Defines the entry point for the application.
//

#include "framework.h"
#include "Saper.h"

#define MAX_LOADSTRING 100
#define PIECE_SIZE 25
#define MIN_X_SIZE 10
#define MAX_X_SIZE 30
#define MIN_Y_SIZE 10
#define MAX_Y_SIZE 24
#define TOP_PANEL 30

HINSTANCE hInst;
WCHAR szTitle[MAX_LOADSTRING];
WCHAR szWindowClass[MAX_LOADSTRING];
WCHAR szPieceClass[MAX_LOADSTRING];
HWND szPieces[MAX_X_SIZE][MAX_Y_SIZE];
BOOL xNoObjects;
BOOL yNoObjects;
BOOL DEBUG = FALSE;

ATOM                RegisterMainClass(HINSTANCE hInstance);
ATOM                RegisterPieceClass(HINSTANCE hInstance);
BOOL                InitInstance(HINSTANCE, int);
BOOL                InitPieces(HWND);
BOOL                ResetGame(HWND);
LRESULT CALLBACK    WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK    WndPieceProc(HWND, UINT, WPARAM, LPARAM);
INT_PTR CALLBACK    About(HWND, UINT, WPARAM, LPARAM);

struct TIME_ST
{
    ULONGLONG begin;
};

int APIENTRY wWinMain(_In_ HINSTANCE hInstance,
                     _In_opt_ HINSTANCE hPrevInstance,
                     _In_ LPWSTR    lpCmdLine,
                     _In_ int       nCmdShow)
{
    UNREFERENCED_PARAMETER(hPrevInstance);
    UNREFERENCED_PARAMETER(lpCmdLine);

    LoadStringW(hInstance, IDS_APP_TITLE, szTitle, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_SAPER, szWindowClass, MAX_LOADSTRING);
    LoadStringW(hInstance, IDC_PIECE, szPieceClass, MAX_LOADSTRING);
    
    RegisterMainClass(hInstance);
    RegisterPieceClass(hInstance);

    srand(0);

    if (!InitInstance (hInstance, nCmdShow))
    {
        return FALSE;
    }

    HACCEL hAccelTable = LoadAccelerators(hInstance, MAKEINTRESOURCE(IDC_SAPER));

    MSG msg;

    // Main message loop:
    while (GetMessage(&msg, nullptr, 0, 0))
    {
        if (!TranslateAccelerator(msg.hwnd, hAccelTable, &msg))
        {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
    }

    return (int) msg.wParam;
}


ATOM RegisterMainClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style          = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc    = WndProc;
    wcex.cbClsExtra     = 0;
    wcex.cbWndExtra     = 0;
    wcex.hInstance      = hInstance;
    wcex.hIcon          = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_SAPER));
    wcex.hCursor        = LoadCursor(nullptr, IDC_ARROW);
    wcex.hbrBackground  = (HBRUSH)(COLOR_WINDOW+1);
    wcex.lpszMenuName   = MAKEINTRESOURCEW(IDC_SAPER);
    wcex.lpszClassName  = szWindowClass;
    wcex.hIconSm        = LoadIcon(wcex.hInstance, MAKEINTRESOURCE(IDI_SMALL));

    return RegisterClassExW(&wcex);
}

ATOM RegisterPieceClass(HINSTANCE hInstance)
{
    WNDCLASSEXW wcex;

    wcex.cbSize = sizeof(WNDCLASSEX);

    wcex.style = CS_HREDRAW | CS_VREDRAW;
    wcex.lpfnWndProc = WndPieceProc;
    wcex.cbClsExtra = 0;
    wcex.cbWndExtra = 0;
    wcex.hInstance = hInstance;
    wcex.hIcon = NULL;
    wcex.hCursor = NULL;
    wcex.hbrBackground = CreateSolidBrush(RGB(0xC8, 0xC8, 0xC8));
    wcex.lpszMenuName = NULL;
    wcex.lpszClassName = szPieceClass;
    wcex.hIconSm = NULL;

    return RegisterClassExW(&wcex);
}

BOOL InitInstance(HINSTANCE hInstance, int nCmdShow)
{
   hInst = hInstance; // Store instance handle in our global variable

   int x = GetSystemMetrics(SM_CXSCREEN);
   int y = GetSystemMetrics(SM_CYSCREEN);

   xNoObjects = rand() % (MAX_X_SIZE - MIN_X_SIZE + 1) + MIN_X_SIZE;
   yNoObjects = rand() % (MAX_Y_SIZE - MIN_Y_SIZE + 1) + MIN_Y_SIZE;

   RECT rt = {0, 0, xNoObjects * (PIECE_SIZE + 1) + 1, yNoObjects * (PIECE_SIZE + 1) + 1 + TOP_PANEL};

   AdjustWindowRect(&rt, WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME, TRUE);

   TIME_ST* st = new TIME_ST;
   st->begin = GetTickCount64();
   HWND hWnd = CreateWindowW(szWindowClass, szTitle, WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME,
       (x - rt.right) / 2, (y - rt.bottom) / 2, rt.right - rt.left, rt.bottom - rt.top, nullptr, nullptr, hInstance, st);

   if (!hWnd)
   {
      return FALSE;
   }

   ShowWindow(hWnd, nCmdShow);
   UpdateWindow(hWnd);

   InitPieces(hWnd);

   return TRUE;
}


LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
        {
            int wmId = LOWORD(wParam);
            // Parse the menu selections:
            switch (wmId)
            {
            case ID_GAME_NEW:
                ResetGame(hWnd);
                break;
            case ID_HELP_DEBUG:
                if (!DEBUG)
                {
                    CheckMenuItem(GetMenu(hWnd), ID_HELP_DEBUG, MF_CHECKED);
                    MessageBox(hWnd, L"Debug", L"Debug", MB_OK);
                    DEBUG = TRUE;
                }
                else
                {
                    CheckMenuItem(GetMenu(hWnd), ID_HELP_DEBUG, MF_UNCHECKED);
                    DEBUG = FALSE;
                }
                break;
            case ID_GAME_EXIT:
                DestroyWindow(hWnd);
                break;
            default:
                return DefWindowProc(hWnd, message, wParam, lParam);
            }
        }
        break;
    case WM_CREATE:
    {
        CREATESTRUCT* pCreate = reinterpret_cast<CREATESTRUCT*>(lParam);
        TIME_ST* pState = reinterpret_cast<TIME_ST*>(pCreate->lpCreateParams);
        SetWindowLongPtr(hWnd, GWLP_USERDATA, reinterpret_cast<LONG_PTR>(pState));
        SetTimer(hWnd, 1, 50, NULL);
        break;
    }
    case WM_TIMER:
    {
        if (wParam == 1)
        {
            TIME_ST* pS = reinterpret_cast<TIME_ST*>(GetWindowLongPtr(hWnd, GWLP_USERDATA));
            ULONGLONG ms = GetTickCount64();
            ms = (ms - pS->begin) / 100;
            int msec = ms % 10;
            int sec = ms / 10;
            TCHAR s[8];
            if (sec < 10)
            {
                _stprintf_s(s, 8, _T("000%d.%d"), sec, msec);
            }
            else if (sec < 100)
            {
                _stprintf_s(s, 8, _T("00%d.%d"), sec, msec);
            }
            else if (sec < 1000)
            {
                _stprintf_s(s, 8, _T("0%d.%d"), sec, msec);
            }
            else
            {
                _stprintf_s(s, 8, _T("%d.%d"), sec, msec);
            }
            SetWindowText(hWnd, s);
            SetTimer(hWnd, 1, 50, NULL);
        }
        break;
    }
    case WM_PAINT:
        {
            PAINTSTRUCT ps;
            HDC hdc = BeginPaint(hWnd, &ps);
            // TODO: Add any drawing code that uses hdc here...
            EndPaint(hWnd, &ps);
        }
        break;
    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

LRESULT CALLBACK WndPieceProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
    switch (message)
    {
    case WM_COMMAND:
    {
        int wmId = LOWORD(wParam);
        // Parse the menu selections:
        switch (wmId)
        {
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
        }
        break;
    }
    case WM_PAINT:
    {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hWnd, &ps);
        // TODO: Add any drawing code that uses hdc here...
        EndPaint(hWnd, &ps);
    }
    break;
    default:
        return DefWindowProc(hWnd, message, wParam, lParam);
    }
    return 0;
}

BOOL InitPieces(HWND parent)
{
    for (int x = 0; x < xNoObjects; x++)
    {
        for (int y = 0; y < yNoObjects; y++)
        {
            szPieces[x][y] = CreateWindowW(szPieceClass, szTitle, WS_VISIBLE | WS_CHILD,
                1 + x * (1 + PIECE_SIZE), TOP_PANEL + 1 + y * (1 + PIECE_SIZE), PIECE_SIZE, PIECE_SIZE,
                parent, nullptr, hInst, nullptr);
        }
    }

    return 0;
}

BOOL ResetGame(HWND hWnd)
{
    int x = GetSystemMetrics(SM_CXSCREEN);
    int y = GetSystemMetrics(SM_CYSCREEN);

    xNoObjects = rand() % (MAX_X_SIZE - MIN_X_SIZE + 1) + MIN_X_SIZE;
    yNoObjects = rand() % (MAX_Y_SIZE - MIN_Y_SIZE + 1) + MIN_Y_SIZE;

    RECT rt = { 0, 0, xNoObjects * (PIECE_SIZE + 1) + 1, yNoObjects * (PIECE_SIZE + 1) + 1 + TOP_PANEL};
    AdjustWindowRect(&rt, WS_OVERLAPPEDWINDOW ^ WS_THICKFRAME, TRUE);

    for (int i = 0; i < xNoObjects; i++)
    {
        for (int j = 0; j < yNoObjects; j++)
        {
            DestroyWindow(szPieces[i][j]);
        }
    }

    MoveWindow(hWnd, (x - rt.right) / 2, (y - rt.bottom) / 2, rt.right - rt.left, rt.bottom - rt.top, TRUE);
    InitPieces(hWnd);
    return 0;
}


